import React from 'react';
import { Link } from 'react-router-dom';
import { Users, UserPlus } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold flex items-center">
          <Users className="mr-2" />
          Contact Manager
        </Link>
        <nav>
          <Link to="/add" className="bg-white text-blue-600 px-4 py-2 rounded-full flex items-center hover:bg-blue-100 transition-colors">
            <UserPlus className="mr-2" />
            Add Contact
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;