import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

export interface Contact {
  id: string;
  name: string;
  primaryPhone: string;
  secondaryPhone: string;
  email: string;
  rating: number;
  instagramId: string;
  facebookId: string;
  linkedIn: string;
  birthday: string;
  currentBusiness: string;
  industry: string;
  position: string;
  residenceAddress: string;
  businessAddress: string;
  notes: string;
  tags: string[];
  engagementFrequency: string;
  interactions: Interaction[];
  engagementReminders: EngagementReminder[];
  documents: Document[];
}

export interface Interaction {
  id: string;
  date: string;
  type: 'call' | 'message' | 'social';
  notes: string;
}

export interface EngagementReminder {
  id: string;
  contactId: string;
  dateTime: string;
  type: string;
  details: string;
  status: 'Done' | 'Pending' | 'Overdue';
}

export interface Document {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
}

interface ContactContextType {
  contacts: Contact[];
  addContact: (contact: Omit<Contact, 'id' | 'interactions' | 'engagementReminders' | 'documents'>) => void;
  updateContact: (id: string, contact: Partial<Contact>) => void;
  deleteContact: (id: string) => void;
  addInteraction: (contactId: string, interaction: Omit<Interaction, 'id'>) => void;
  addEngagementReminder: (reminder: Omit<EngagementReminder, 'id'>) => void;
  updateEngagementReminder: (reminderId: string, reminder: Partial<EngagementReminder>) => void;
  getAllTags: () => string[];
  searchContacts: (query: string) => Contact[];
  addDocument: (contactId: string, document: Omit<Document, 'id'>) => void;
  calculateProfileCompleteness: (contact: Contact) => number;
}

const ContactContext = createContext<ContactContextType | undefined>(undefined);

export const useContacts = () => {
  const context = useContext(ContactContext);
  if (!context) {
    throw new Error('useContacts must be used within a ContactProvider');
  }
  return context;
};

export const ContactProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [contacts, setContacts] = useState<Contact[]>([]);

  useEffect(() => {
    const storedContacts = localStorage.getItem('contacts');
    if (storedContacts) {
      setContacts(JSON.parse(storedContacts));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('contacts', JSON.stringify(contacts));
  }, [contacts]);

  const addContact = (contact: Omit<Contact, 'id' | 'interactions' | 'engagementReminders' | 'documents'>) => {
    setContacts([...contacts, { ...contact, id: uuidv4(), interactions: [], engagementReminders: [], documents: [] }]);
  };

  const updateContact = (id: string, updatedContact: Partial<Contact>) => {
    setContacts(contacts.map(contact => 
      contact.id === id ? { ...contact, ...updatedContact } : contact
    ));
  };

  const deleteContact = (id: string) => {
    setContacts(contacts.filter(contact => contact.id !== id));
  };

  const addInteraction = (contactId: string, interaction: Omit<Interaction, 'id'>) => {
    setContacts(contacts.map(contact => 
      contact.id === contactId
        ? { ...contact, interactions: [...contact.interactions, { ...interaction, id: uuidv4() }] }
        : contact
    ));
  };

  const addEngagementReminder = (reminder: Omit<EngagementReminder, 'id'>) => {
    setContacts(contacts.map(contact => 
      contact.id === reminder.contactId
        ? { ...contact, engagementReminders: [...contact.engagementReminders, { ...reminder, id: uuidv4() }] }
        : contact
    ));
  };

  const updateEngagementReminder = (reminderId: string, updatedReminder: Partial<EngagementReminder>) => {
    setContacts(contacts.map(contact => ({
      ...contact,
      engagementReminders: contact.engagementReminders.map(reminder =>
        reminder.id === reminderId ? { ...reminder, ...updatedReminder } : reminder
      )
    })));
  };

  const getAllTags = () => {
    return Array.from(new Set(contacts.flatMap(contact => contact.tags)));
  };

  const searchContacts = (query: string) => {
    const lowercaseQuery = query.toLowerCase();
    return contacts.filter(contact => 
      contact.name.toLowerCase().includes(lowercaseQuery) ||
      contact.primaryPhone.includes(query) ||
      contact.email.toLowerCase().includes(lowercaseQuery) ||
      contact.industry.toLowerCase().includes(lowercaseQuery) ||
      contact.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery)) ||
      contact.residenceAddress.toLowerCase().includes(lowercaseQuery) ||
      contact.businessAddress.toLowerCase().includes(lowercaseQuery)
    );
  };

  const addDocument = (contactId: string, document: Omit<Document, 'id'>) => {
    setContacts(contacts.map(contact => 
      contact.id === contactId
        ? { ...contact, documents: [...contact.documents, { ...document, id: uuidv4() }] }
        : contact
    ));
  };

  const calculateProfileCompleteness = (contact: Contact) => {
    const fields = [
      'name', 'primaryPhone', 'email', 'industry', 'residenceAddress', 'businessAddress',
      'birthday', 'currentBusiness', 'position', 'tags'
    ];
    const completedFields = fields.filter(field => {
      const value = contact[field as keyof Contact];
      return value && (Array.isArray(value) ? value.length > 0 : true);
    });
    return Math.round((completedFields.length / fields.length) * 100);
  };

  return (
    <ContactContext.Provider value={{ 
      contacts, 
      addContact, 
      updateContact, 
      deleteContact, 
      addInteraction, 
      addEngagementReminder, 
      updateEngagementReminder,
      getAllTags,
      searchContacts,
      addDocument,
      calculateProfileCompleteness
    }}>
      {children}
    </ContactContext.Provider>
  );
};