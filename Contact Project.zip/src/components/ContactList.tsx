import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useContacts } from '../contexts/ContactContext';
import { Star, Phone, Mail, MessageCircle, Search } from 'lucide-react';
import Calendar from './Calendar';

const ContactList: React.FC = () => {
  const { contacts, searchContacts, calculateProfileCompleteness } = useContacts();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredContacts = searchQuery ? searchContacts(searchQuery) : contacts;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="md:col-span-2">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Contact List ({contacts.length})</h2>
          <div className="relative">
            <input
              type="text"
              placeholder="Search contacts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border rounded-full w-64"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {filteredContacts.map(contact => (
            <Link key={contact.id} to={`/contact/${contact.id}`} className="bg-white p-4rounded-lg shadow hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-2">{contact.name}</h3>
              <div className="flex items-center mb-2">
                {[...Array(5)].map((_, index) => (
                  <Star key={index} className={`w-4 h-4 ${index < contact.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                ))}
              </div>
              <div className="flex items-center text-gray-600 mb-1">
                <Phone className="w-4 h-4 mr-2" />
                {contact.primaryPhone}
                <a href={`https://wa.me/${contact.primaryPhone.replace(/\D/g,'')}`} target="_blank" rel="noopener noreferrer" className="ml-2">
                  <MessageCircle className="w-4 h-4 text-green-500" />
                </a>
              </div>
              <div className="flex items-center text-gray-600 mb-2">
                <Mail className="w-4 h-4 mr-2" />
                {contact.email}
              </div>
              <div className="flex flex-wrap gap-1 mb-2">
                {contact.tags.map((tag, index) => (
                  <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">{tag}</span>
                ))}
              </div>
              <div className="text-sm text-gray-500">
                Industry: {contact.industry}
              </div>
              <div className="mt-2 bg-gray-100 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${calculateProfileCompleteness(contact)}%` }}
                ></div>
              </div>
              <div className="text-xs text-right mt-1">
                Profile: {calculateProfileCompleteness(contact)}% complete
              </div>
            </Link>
          ))}
        </div>
      </div>
      <div>
        <Calendar />
      </div>
    </div>
  );
};

export default ContactList;