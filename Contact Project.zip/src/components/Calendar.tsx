import React from 'react';
import { useContacts } from '../contexts/ContactContext';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const Calendar: React.FC = () => {
  const { contacts } = useContacts();
  const allReminders = contacts.flatMap(contact => 
    contact.engagementReminders.map(reminder => ({
      ...reminder,
      contactName: contact.name
    }))
  );

  const [selectedDate, setSelectedDate] = React.useState(new Date());

  const remindersForSelectedDate = allReminders.filter(reminder => 
    new Date(reminder.dateTime).toDateString() === selectedDate.toDateString()
  );

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">Engagement Calendar</h2>
      <DatePicker
        selected={selectedDate}
        onChange={(date: Date) => setSelectedDate(date)}
        inline
      />
      <div className="mt-4">
        <h3 className="font-semibold mb-2">Reminders for {selectedDate.toDateString()}</h3>
        {remindersForSelectedDate.length > 0 ? (
          <ul className="space-y-2">
            {remindersForSelectedDate.map(reminder => (
              <li key={reminder.id} className="bg-gray-100 p-2 rounded">
                <p className="font-semibold">{reminder.contactName}</p>
                <p>{reminder.type} - {reminder.details}</p>
                <p className={`text-sm ${
                  reminder.status === 'Done' ? 'text-green-600' :
                  reminder.status === 'Pending' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {reminder.status}
                </p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No reminders for this date.</p>
        )}
      </div>
    </div>
  );
};

export default Calendar;