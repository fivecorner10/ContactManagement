import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useContacts, EngagementReminder } from '../contexts/ContactContext';
import { Star, Phone, Mail, Instagram, Facebook, Linkedin, Calendar, Briefcase, MapPin, Tag, Clock, Trash, MessageCircle, Edit, Upload } from 'lucide-react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const ContactDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { contacts, updateContact, deleteContact, addInteraction, addEngagementReminder, updateEngagementReminder, addDocument, calculateProfileCompleteness } = useContacts();
  const contact = contacts.find(c => c.id === id);

  const [newInteraction, setNewInteraction] = useState({ type: 'call', notes: '' });
  const [isEditing, setIsEditing] = useState(false);
  const [editedContact, setEditedContact] = useState(contact);
  const [newReminder, setNewReminder] = useState<Omit<EngagementReminder, 'id' | 'contactId'>>({
    dateTime: new Date().toISOString(),
    type: '',
    details: '',
    status: 'Pending'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!contact) {
    return <div>Contact not found</div>;
  }

  const handleInteractionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addInteraction(contact.id, { ...newInteraction, date: new Date().toISOString() });
    setNewInteraction({ type: 'call', notes: '' });
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this contact?')) {
      deleteContact(contact.id);
      navigate('/');
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedContact(contact);
  };

  const handleSave = () => {
    if (editedContact) {
      updateContact(contact.id, editedContact);
      setIsEditing(false);
    }
  };

  const handleReminderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addEngagementReminder({ ...newReminder, contactId: contact.id });
    setNewReminder({
      dateTime: new Date().toISOString(),
      type: '',
      details: '',
      status: 'Pending'
    });
  };

  const handleReminderStatusChange = (reminderId: string, newStatus: 'Done' | 'Pending' | 'Overdue') => {
    updateEngagementReminder(reminderId, { status: newStatus });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 25 * 1024 * 1024) {
        alert('File size exceeds 25MB limit');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        addDocument(contact.id, {
          name: file.name,
          type: file.type,
          size: file.size,
          url: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4 flex items-center justify-between">
        {contact.name}
        {!isEditing && (
          <button onClick={handleEdit} className="text-blue-600 hover:text-blue-800">
            <Edit className="w-6 h-6" />
          </button>
        )}
      </h2>
      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">Contact Information</h3>
            {isEditing ? (
              <>
                <input
                  type="text"
                  value={editedContact?.name}
                  onChange={(e) => setEditedContact({ ...editedContact!, name: e.target.value })}
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="tel"
                  value={editedContact?.primaryPhone}
                  onChange={(e) => setEditedContact({ ...editedContact!, primaryPhone: e.target.value })}
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="email"
                  value={editedContact?.email}
                  onChange={(e) => setEditedContact({ ...editedContact!, email: e.target.value })}
                  className="w-full p-2 border rounded mb-2"
                />
                <select
                  value={editedContact?.rating}
                  onChange={(e) => setEditedContact({ ...editedContact!, rating: Number(e.target.value) })}
                  className="w-full p-2 border rounded mb-2"
                >
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <option key={rating} value={rating}>{rating} Star{rating !== 1 ? 's' : ''}</option>
                  ))}
                </select>
              </>
            ) : (
              <>
                <div className="flex items-center mb-2">
                  <Phone className="w-5 h-5 mr-2 text-gray-600" />
                  <a href={`tel:${contact.primaryPhone}`} className="text-blue-600 hover:underline">{contact.primaryPhone}</a>
                  <a href={`https://wa.me/${contact.primaryPhone.replace(/\D/g,'')}`} target="_blank" rel="noopener noreferrer" className="ml-2">
                    <MessageCircle className="w-5 h-5 text-green-500" />
                  </a>
                </div>
                {contact.secondaryPhone && (
                  <div className="flex items-center mb-2">
                    <Phone className="w-5 h-5 mr-2 text-gray-600" />
                    <a href={`tel:${contact.secondaryPhone}`} className="text-blue-600 hover:underline">{contact.secondaryPhone}</a>
                    <a href={`https://wa.me/${contact.secondaryPhone.replace(/\D/g,'')}`} target="_blank" rel="noopener noreferrer" className="ml-2">
                      <MessageCircle className="w-5 h-5 text-green-500" />
                    </a>
                  </div>
                )}
                <div className="flex items-center mb-2">
                  <Mail className="w-5 h-5 mr-2 text-gray-600" />
                  <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">{contact.email}</a>
                </div>
                <div className="flex items-center mb-2">
                  <Star className="w-5 h-5 mr-2 text-yellow-400" />
                  <span>{contact.rating} / 5</span>
                </div>
              </>
            )}
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Social Media</h3>
            {isEditing ? (
              <>
                <input
                  type="text"
                  value={editedContact?.instagramId}
                  onChange={(e) => setEditedContact({ ...editedContact!, instagramId: e.target.value })}
                  placeholder="Instagram ID"
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="text"
                  value={editedContact?.facebookId}
                  onChange={(e) => setEditedContact({ ...editedContact!, facebookId: e.target.value })}
                  placeholder="Facebook ID"
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="text"
                  value={editedContact?.linkedIn}
                  onChange={(e) => setEditedContact({ ...editedContact!, linkedIn: e.target.value })}
                  placeholder="LinkedIn URL"
                  className="w-full p-2 border rounded mb-2"
                />
              </>
            ) : (
              <>
                {contact.instagramId && (
                  <div className="flex items-center mb-2">
                    <Instagram className="w-5 h-5 mr-2 text-gray-600" />
                    <a href={`https://instagram.com/${contact.instagramId}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{contact.instagramId}</a>
                  </div>
                )}
                {contact.facebookId && (
                  <div className="flex items-center mb-2">
                    <Facebook className="w-5 h-5 mr-2 text-gray-600" />
                    <a href={`https://facebook.com/${contact.facebookId}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{contact.facebookId}</a>
                  </div>
                )}
                {contact.linkedIn && (
                  <div className="flex items-center mb-2">
                    <Linkedin className="w-5 h-5 mr-2 text-gray-600" />
                    <a href={contact.linkedIn} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">LinkedIn Profile</a>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
        {isEditing && (
          <button onClick={handleSave} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">
            Save Changes
          </button>
        )}
      </div>

      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <h3 className="text-xl font-semibold mb-2">Additional Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            {isEditing ? (
              <>
                <input
                  type="date"
                  value={editedContact?.birthday}
                  onChange={(e) => setEditedContact({ ...editedContact!, birthday: e.target.value })}
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="text"
                  value={editedContact?.position}
                  onChange={(e) => setEditedContact({ ...editedContact!, position: e.target.value })}
                  placeholder="Position"
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="text"
                  value={editedContact?.currentBusiness}
                  onChange={(e) => setEditedContact({ ...editedContact!, currentBusiness: e.target.value })}
                  placeholder="Current Business"
                  className="w-full p-2 border rounded mb-2"
                />
                <input
                  type="text"
                  value={editedContact?.industry}
                  onChange={(e) => setEditedContact({ ...editedContact!, industry: e.target.value })}
                  placeholder="Industry"
                  className="w-full p-2 border rounded mb-2"
                />
              </>
            ) : (
              <>
                <div className="flex items-center mb-2">
                  <Calendar className="w-5 h-5 mr-2 text-gray-600" />
                  <span>Birthday: {contact.birthday}</span>
                </div>
                <div className="flex items-center mb-2">
                  <Briefcase className="w-5 h-5 mr-2 text-gray-600" />
                  <span>{contact.position} at {contact.currentBusiness}</span>
                </div>
                <div className="flex items-center mb-2">
                  <Tag className="w-5 h-5 mr-2 text-gray-600" />
                  <span>Industry: {contact.industry}</span>
                </div>
              </>
            )}
          </div>
          <div>
            {isEditing ? (
              <>
                <textarea
                  value={editedContact?.residenceAddress}
                  onChange={(e) => setEditedContact({ ...editedContact!, residenceAddress: e.target.value })}
                  placeholder="Residence Address"
                  className="w-full p-2 border rounded mb-2"
                />
                <textarea
                  value={editedContact?.businessAddress}
                  onChange={(e) => setEditedContact({ ...editedContact!, businessAddress: e.target.value })}
                  placeholder="Business Address"
                  className="w-full p-2 border rounded mb-2"
                />
              </>
            ) : (
              <>
                <div className="mb-2">
                  <MapPin className="w-5 h-5 mr-2 text-gray-600 inline" />
                  <span className="font-semibold">Residence Address:</span>
                  <p className="ml-7">{contact.residenceAddress}</p>
                </div>
                <div className="mb-2">
                  <MapPin className="w-5 h-5 mr-2 text-gray-600 inline" />
                  <span className="font-semibold">Business Address:</span>
                  <p className="ml-7">{contact.businessAddress}</p>
                </div>
              </>
            )}
          </div>
        </div>
        <div className="mt-4">
          <h4 className="font-semibold mb-2">Notes:</h4>
          {isEditing ? (
            <textarea
              value={editedContact?.notes}
              onChange={(e) => setEditedContact({ ...editedContact!, notes: e.target.value })}
              className="w-full p-2 border rounded mb-2"
            />
          ) : (
            <p>{contact.notes}</p>
          )}
        </div>
        <div className="mt-4">
          <h4 className="font-semibold mb-2">Tags:</h4>
          {isEditing ? (
            <input
              type="text"
              value={editedContact?.tags.join(', ')}
              onChange={(e) => setEditedContact({ ...editedContact!, tags: e.target.value.split(',').map(tag => tag.trim()) })}
              className="w-full p-2 border rounded mb-2"
            />
          ) : (
            <div className="flex flex-wrap gap-2">
              {contact.tags.map((tag, index) => (
                <span key={index} className="bg-gray-200 px-2 py-1 rounded-full text-sm">{tag}</span>
              ))}
            </div>
          )}
        </div>
        <div className="mt-4">
          <h4 className="font-semibold mb-2">Profile Completeness:</h4>
          <div className="bg-gray-200 rounded-full h-4">
            <div
              className="bg-blue-600 rounded-full h-4"
              style={{ width: `${calculateProfileCompleteness(contact)}%` }}
            ></div>
          </div>
          <p className="text-sm mt-1">{calculateProfileCompleteness(contact)}% complete</p>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <h3 className="text-xl font-semibold mb-2">Engagement</h3>
        <div className="flex items-center mb-4">
          <Clock className="w-5 h-5 mr-2 text-gray-600" />
          <span>Frequency: {contact.engagementFrequency}</span>
        </div>
        <h4 className="font-semibold mb-2">Interaction History</h4>
        <ul className="space-y-2">
          {contact.interactions.map(interaction => (
            <li key={interaction.id} className="bg-gray-100 p-2 rounded">
              <span className="font-semibold">{new Date(interaction.date).toLocaleString()}</span> - {interaction.type}
              <p>{interaction.notes}</p>
            </li>
          ))}
        </ul>
        <form onSubmit={handleInteractionSubmit} className="mt-4">
          <h4 className="font-semibold mb-2">Add New Interaction</h4>
          <div className="flex gap-2 mb-2">
            <select
              value={newInteraction.type}
              onChange={(e) => setNewInteraction({ ...newInteraction, type: e.target.value as 'call' | 'message' | 'social' })}
              className="p-2 border rounded"
            >
              <option value="call">Call</option>
              <option value="message">Message</option>
              <option value="social">Social</option>
            </select>
            <input
              type="text"
              value={newInteraction.notes}
              onChange={(e) => setNewInteraction({ ...newInteraction, notes: e.target.value })}
              placeholder="Interaction notes"
              className="flex-grow p-2 border rounded"
            />
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">Add</button>
          </div>
        </form>
      </div>

      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <h3 className="text-xl font-semibold mb-2">Engagement Reminders</h3>
        <ul className="space-y-2 mb-4">
          {contact.engagementReminders.map(reminder => (
            <li key={reminder.id} className="bg-gray-100 p-2 rounded flex justify-between items-center">
              <div>
                <p className="font-semibold">{new Date(reminder.dateTime).toLocaleString()}</p>
                <p>{reminder.type} - {reminder.details}</p>
              </div>
              <select
                value={reminder.status}
                onChange={(e) => handleReminderStatusChange(reminder.id, e.target.value as 'Done' | 'Pending' | 'Overdue')}
                className="p-1 border rounded"
              >
                <option value="Done">Done</option>
                <option value="Pending">Pending</option>
                <option value="Overdue">Overdue</option>
              </select>
            </li>
          ))}
        </ul>
        <form onSubmit={handleReminderSubmit}>
          <h4 className="font-semibold mb-2">Add New Reminder</h4>
          <div className="space-y-2">
            <DatePicker
              selected={new Date(newReminder.dateTime)}
              onChange={(date: Date) => setNewReminder({ ...newReminder, dateTime: date.toISOString() })}
              showTimeSelect
              dateFormat="Pp"
              className="w-full p-2 border rounded"
            />
            <input
              type="text"
              value={newReminder.type}
              onChange={(e) => setNewReminder({ ...newReminder, type: e.target.value })}
              placeholder="Reminder type"
              className="w-full p-2 border rounded"
            />
            <input
              type="text"
              value={newReminder.details}
              onChange={(e) => setNewReminder({ ...newReminder, details: e.target.value })}
              placeholder="Reminder details"
              className="w-full p-2 border rounded"
            />
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">Add Reminder</button>
          </div>
        </form>
      </div>

      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <h3 className="text-xl font-semibold mb-2">Documents</h3>
        <ul className="space-y-2 mb-4">
          {contact.documents.map(doc => (
            <li key={doc.id} className="flex items-center justify-between bg-gray-100 p-2 rounded">
              <span>{doc.name}</span>
              <a href={doc.url} download={doc.name} className="text-blue-600 hover:underline">Download</a>
            </li>
          ))}
        </ul>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          className="hidden"
          accept="*/*"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors flex items-center"
        >
          <Upload className="w-5 h-5 mr-2" />
          Upload Document
        </button>
      </div>

      <div className="flex justify-between">
        <button onClick={() => navigate('/')} className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition-colors">Back to List</button>
        <button onClick={handleDelete} className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors flex items-center">
          <Trash className="w-5 h-5 mr-2" />
          Delete Contact
        </button>
      </div>
    </div>
  );
};

export default ContactDetails;