import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useContacts } from '../contexts/ContactContext';
import CreatableSelect from 'react-select/creatable';

const AddContact: React.FC = () => {
  const navigate = useNavigate();
  const { addContact, getAllTags } = useContacts();
  const [contact, setContact] = useState({
    name: '',
    primaryPhone: '',
    secondaryPhone: '',
    email: '',
    rating: 0,
    instagramId: '',
    facebookId: '',
    linkedIn: '',
    birthday: '',
    currentBusiness: '',
    industry: '',
    position: '',
    residenceAddress: '',
    businessAddress: '',
    notes: '',
    tags: [] as string[],
    engagementFrequency: ''
  });

  const allTags = getAllTags();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setContact(prev => ({ ...prev, [name]: value }));
  };

  const handleTagChange = (newValue: any, actionMeta: any) => {
    if (actionMeta.action === 'create-option') {
      setContact(prev => ({ ...prev, tags: [...prev.tags, newValue[newValue.length - 1].value] }));
    } else {
      setContact(prev => ({ ...prev, tags: newValue.map((v: any) => v.value) }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addContact({
      ...contact,
      rating: Number(contact.rating)
    });
    navigate('/');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Add New Contact</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* ... (existing form fields) ... */}
        <div>
          <label className="block mb-1">Tags</label>
          <CreatableSelect
            isMulti
            options={allTags.map(tag => ({ value: tag, label: tag }))}
            value={contact.tags.map(tag => ({ value: tag, label: tag }))}
            onChange={handleTagChange}
            className="w-full"
          />
        </div>
        {/* ... (remaining form fields) ... */}
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">Add Contact</button>
      </form>
    </div>
  );
};

export default AddContact;